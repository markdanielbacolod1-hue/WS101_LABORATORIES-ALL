package objects.activity6;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Product {
  private String name;
  private double price;

  public Product(String name, double price) {
    this.name = name;
    this.price = price;
  }

  public String getName() {
    return name;
  }

  public double getPrice() {
    return price;
  }
}

public class act {
  public static void main(String[] args) {
    List<Product> products = new ArrayList<>();
    products.add(new Product("Apple", 10.99));
    products.add(new Product("Banana", 5.99));
    products.add(new Product("Orange", 8.99));
    products.add(new Product("Apple", 12.99));
    products.add(new Product("Grapes", 15.99));

    long count = products.stream()
      .filter(product -> product.getPrice() > 10)
      .count();
    System.out.println("Products with price > 10: " + count);

    count = products.stream()
      .filter(product -> product.getName().equals("Apple"))
      .count();
    System.out.println("Products with name 'Apple': " + count);

    List<String> productNames = products.stream()
      .filter(product -> product.getPrice() > 10)
      .map(Product::getName)
      .collect(Collectors.toList());
    System.out.println("Products with price > 10: " + productNames);
  }
}
