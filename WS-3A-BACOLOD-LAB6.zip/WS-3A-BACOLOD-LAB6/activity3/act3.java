package objects.activity3;
import java.util.Scanner;
public class act3 {
    public static void main (String[]args) {
        int[] Numberr = new int[5];
        Scanner scanner = new Scanner(System.in);
        for(int i = 0;i<5;i++){
            System.out.println("Enter array"+(i+1));
            Numberr[i] = scanner.nextInt();
        }
        scanner.close();
        System.out.println("You entered: ");
        for(int i = 0;i<5;i++) {
            System.out.println(Numberr[i]);
        }
        int plus = 0;
        for(int i = 0; i <5;i++) {
            plus += Numberr[i];
        }
        System.out.print("the sum is: "+ plus);
    }
}
