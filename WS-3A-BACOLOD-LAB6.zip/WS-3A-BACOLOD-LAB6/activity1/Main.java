package objects.activity1;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        
        Person person = new Person();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Name: ");
        person.setName(scanner.nextLine());

        System.out.print ("Enter age: ");
        person.setAge(scanner.nextInt());
        System.out.print("Hello "+person.name+ " you are "+person.age+ " years old");
    }
}
