package objects.activity5;

public class rectangle {
    double width;
    double length;

    public rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }
    public double calculateArea() {
        return width * length;
    }
    public static void main(String[] args) {
        rectangle rect = new rectangle(5.0, 10.0);
        System.out.print("Area is " + rect.calculateArea());
    }
}
