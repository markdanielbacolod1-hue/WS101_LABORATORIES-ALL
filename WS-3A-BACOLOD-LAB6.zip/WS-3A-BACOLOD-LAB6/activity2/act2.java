package objects.activity2;
import java.util.Scanner;
public class act2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter fibonnaci terms: ");
        int nterm = scanner.nextInt();

        scanner.close();
        int num1 = 0, nume2 = 1;
        System.out.print("Fibonnacci series upto "+nterm+" series");
        for (int i = 0; i<=nterm;i++) {
            System.out.print(num1+", ");
            int sum = num1 + nume2;
            num1 = nume2;
            nume2 = sum;
        }
    }
}
