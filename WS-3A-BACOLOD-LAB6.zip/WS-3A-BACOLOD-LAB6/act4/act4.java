package objects.act4;
import java.util.Scanner;
public class act4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter word: ");
        String word = scanner.nextLine();

        if (isIt(word)) {
            System.out.print(word+" is palindrome");
        } else {
            System.out.print(word+" is not palindrome");
        }
    }
    public static boolean isIt(String wordd) {
        int left = 0;
        int right = wordd.length() - 1;
        while(left < right) {
            if (wordd.charAt(left) != wordd.charAt(right)) {
                return false;
            }
            left ++;
            right --;
        }
        return true;
    }
}
